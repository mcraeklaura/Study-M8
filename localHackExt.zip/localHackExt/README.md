Google Chrome Extension:

Load it:
      - In Google Chrome type the following url: chrome://extensions/
      - Next, check "Developer mode"
      - Click: "Load unpacked extension".
      - Navigate to the "localHackExt" folder and upload it
      - Ensure that the enabled checkbox is checked
  
Fill out the: url, userid, tag, comment, and press submit
  